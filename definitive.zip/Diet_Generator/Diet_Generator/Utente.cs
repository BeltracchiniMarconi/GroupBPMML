﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diet_Generator
{
    class Utente
    {
        #region essentials
        private string username;
        private string password;
        private string preferenze;
        private double circonferenzaCaviglia;
        private double circonferenzaPolsi;
        private double circonferenzaBacino;
        private double altezza;
        private double peso;
        private double kcal;
        private string attivitàFisica;
        private string sesso;
        private int età;
        private string sport;
        private int bodyFat;
        #region properties
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Preferenze { get => preferenze; set => preferenze = value; }
        public double CirconferenzaCaviglia { get => circonferenzaCaviglia; set => circonferenzaCaviglia = value; }
        public double CirconferenzaPolsi { get => circonferenzaPolsi; set => circonferenzaPolsi = value; }
        public double CirconferenzaBacino { get => circonferenzaBacino; set => circonferenzaBacino = value; }
        public double Altezza { get => altezza; set
            {
                if(value < 50 || value > 3000)
                {
                    altezza = 50;
                    return;
                }
                else
                {
                    altezza = value;
                }

            }
        }
        public double Peso { get => peso; set
            {
                if(value < 10 || value > 550)
                {
                    peso = 10;
                    return;
                }
                else
                {
                    peso = value;
                }
            }
        }
        public string AttivitàFisica { get => attivitàFisica; set => attivitàFisica = value; }
        public string Sesso { get => sesso; set => sesso = value; }
        public int Età { get => età; set
            {
             
                    età = value;
                
            }
        }
        public string Sport { get => sport; set => sport = value; }
        public int BodyFat { get => bodyFat; set
            {
                if(value < 2 || value > 50)
                {
                    return;
                }       
                else
                {
                    bodyFat = value;
                }
            }
        }

        public double Kcal { get => kcal; set => kcal = value; }
        #endregion
        #endregion
        #region costruttori
        public Utente(double a, double p, string s, string aF, int e, string sport)
        {
            AttivitàFisica = aF;
            Peso = p;
            Età = e;
            Altezza = a;
            Sport = sport;
            Sesso = s;
        }
        public Utente(double a, double p, string s, string aF, int e, string sport, int bf)
        {
            AttivitàFisica = aF;
            Peso = p;
            Età = e;
            Altezza = a;
            Sport = sport;
            Sesso = s;
            BodyFat = bf;
        }
        public Utente()
        {

        }
        #endregion
        public override string ToString()
        {
                return $" Sesso:{Sesso} Età:{Età} Altezza:{Altezza}cm Peso:{Peso}kg Attività fisica:{attivitàFisica} Body fat:{BodyFat}%  Sport:{sport}";
        }
    }
}
